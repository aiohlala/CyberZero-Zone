@echo off
chcp 65001 >nul
title CyberZero v1.0.0 - 綠色免安裝版 檔案關聯註冊工具
echo ========================================================
echo   CyberZero v1.0.0 - 輕量 Office 文件閱讀 / 編輯器
echo   綠色免安裝版 — 註冊 Office 檔案開啟關聯 (免系統管理員權限)
echo ========================================================
echo.

set "EXE_PATH=%~dp0cyberzero.exe"
if not exist "%EXE_PATH%" (
    echo [錯誤] 找不到 "%EXE_PATH%"，請確認此批次檔與 cyberzero.exe 位於同一資料夾！
    pause
    exit /b 1
)

set "CAP_PATH=Software\CyberZero\Capabilities"

echo [1/3] 正在註冊應用程式資訊 (HKCU)...
reg add "HKCU\%CAP_PATH%" /v "ApplicationName" /d "CyberZero" /f >nul
reg add "HKCU\%CAP_PATH%" /v "ApplicationDescription" /d "CyberZero 輕量 Office 文件閱讀與編輯器" /f >nul
reg add "HKCU\%CAP_PATH%" /v "ApplicationIcon" /d "\"%EXE_PATH%\",0" /f >nul
reg add "HKCU\Software\RegisteredApplications" /v "CyberZero" /d "%CAP_PATH%" /f >nul

reg add "HKCU\Software\Classes\Applications\cyberzero.exe" /v "FriendlyAppName" /d "CyberZero" /f >nul
reg add "HKCU\Software\Classes\Applications\cyberzero.exe\DefaultIcon" /ve /d "\"%EXE_PATH%\",0" /f >nul
reg add "HKCU\Software\Classes\Applications\cyberzero.exe\shell\open\command" /ve /d "\"%EXE_PATH%\" \"%%1\"" /f >nul

echo [2/3] 正在註冊 Word / Excel / PowerPoint 副檔名關聯...
for %%E in (docx doc xlsx xlsm xls csv ods pptx ppt pdf) do (
    reg add "HKCU\Software\Classes\CyberZero.%%E" /ve /d "Office 文件 (.%%E)" /f >nul
    reg add "HKCU\Software\Classes\CyberZero.%%E\DefaultIcon" /ve /d "\"%EXE_PATH%\",0" /f >nul
    reg add "HKCU\Software\Classes\CyberZero.%%E\shell\open" /ve /d "使用 CyberZero 開啟" /f >nul
    reg add "HKCU\Software\Classes\CyberZero.%%E\shell\open\command" /ve /d "\"%EXE_PATH%\" \"%%1\"" /f >nul
    reg add "HKCU\Software\Classes\.%%E\OpenWithProgids" /v "CyberZero.%%E" /d "" /f >nul
    reg add "HKCU\%CAP_PATH%\FileAssociations" /v ".%%E" /d "CyberZero.%%E" /f >nul
    reg add "HKCU\Software\Classes\Applications\cyberzero.exe\SupportedTypes" /v ".%%E" /d "" /f >nul
)

echo [3/3] 正在開啟 Windows「預設應用程式」設定頁...
start "" "ms-settings:defaultapps?registeredAppUser=CyberZero"

echo.
echo ========================================================
echo   [OK] 註冊完成！
echo   • 請在剛開啟的 Windows 設定頁點選「CyberZero」，將 .docx / .xlsx / .pptx 設為預設。
echo   • 你也可以隨時打開 CyberZero 點擊右上角「預設程式」按鈕逐一設定！
echo   • 注意：若日後移動此綠色版資料夾，請重新執行一次本腳本。
echo ========================================================
echo.
pause
