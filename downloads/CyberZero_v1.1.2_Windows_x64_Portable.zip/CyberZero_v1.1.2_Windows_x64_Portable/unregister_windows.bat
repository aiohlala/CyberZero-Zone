@echo off
chcp 65001 >nul
title CyberZero v1.0.0 - 移除關聯與反安裝工具
echo ========================================================
echo   CyberZero v1.0.0 - 清除檔案關聯與反安裝工具
echo ========================================================
echo.

echo [1/4] 正在關閉執行中的 CyberZero...
taskkill /F /IM cyberzero.exe >nul 2>&1
taskkill /F /IM CyberZero.exe >nul 2>&1

echo [2/4] 正在移除 Office 檔案類型登錄檔關聯...
for %%E in (docx doc xlsx xlsm xls csv ods pptx ppt pdf) do (
    reg delete "HKCU\Software\Classes\CyberZero.%%E" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\.%%E\OpenWithProgids" /v "CyberZero.%%E" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\DocLite.%%E" /f >nul 2>&1
    reg delete "HKCU\Software\Classes\.%%E\OpenWithProgids" /v "DocLite.%%E" /f >nul 2>&1
)
reg delete "HKCU\Software\Classes\Applications\cyberzero.exe" /f >nul 2>&1
reg delete "HKCU\Software\CyberZero" /f >nul 2>&1
reg delete "HKCU\Software\RegisteredApplications" /v "CyberZero" /f >nul 2>&1

echo [3/4] 正在清除桌面與開始功能表捷徑...
del /F /Q "%USERPROFILE%\Desktop\CyberZero.lnk" >nul 2>&1
del /F /Q "%USERPROFILE%\OneDrive\Desktop\CyberZero.lnk" >nul 2>&1
del /F /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\CyberZero.lnk" >nul 2>&1

echo [4/4] 正在清理本機安裝目錄 (若存在)...
if /I "%~dp0"=="%LOCALAPPDATA%\Programs\CyberZero\" (
    start "" /b cmd /c "ping 127.0.0.1 -n 2 >nul & rmdir /s /q \"%LOCALAPPDATA%\Programs\CyberZero\""
) else (
    if exist "%LOCALAPPDATA%\Programs\CyberZero" rmdir /S /Q "%LOCALAPPDATA%\Programs\CyberZero" >nul 2>&1
)

echo.
echo ========================================================
echo   [OK] CyberZero 檔案關聯、捷徑與本機安裝目錄已清除完畢！
echo ========================================================
echo.
pause
