@echo off
chcp 65001 >nul
title CyberZero v1.0.0 - Windows 本機安裝腳本
echo ========================================================
echo   CyberZero v1.0.0 - 輕量 Office 文件閱讀 / 編輯器
echo   Windows 本機安裝 ^& Office 檔案關聯設定 (免管理員權限)
echo ========================================================
echo.

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\CyberZero"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [1/4] 正在檢查並關閉執行中的 CyberZero...
taskkill /F /IM cyberzero.exe >nul 2>&1
taskkill /F /IM CyberZero.exe >nul 2>&1

echo [2/4] 正在複製主程式與元件至 %INSTALL_DIR%...
copy /Y "%~dp0cyberzero.exe" "%INSTALL_DIR%\cyberzero.exe" >nul
if exist "%~dp0WebView2Loader.dll" copy /Y "%~dp0WebView2Loader.dll" "%INSTALL_DIR%\WebView2Loader.dll" >nul
if exist "%~dp0cyberzero.ico" copy /Y "%~dp0cyberzero.ico" "%INSTALL_DIR%\cyberzero.ico" >nul
if exist "%~dp0unregister_windows.bat" copy /Y "%~dp0unregister_windows.bat" "%INSTALL_DIR%\unregister_windows.bat" >nul

echo [3/4] 正在建立桌面與開始功能表捷徑...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $d = [Environment]::GetFolderPath('Desktop'); $ico = '%INSTALL_DIR%\cyberzero.exe,0'; $s = $ws.CreateShortcut($d + '\CyberZero.lnk'); $s.TargetPath = '%INSTALL_DIR%\cyberzero.exe'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.IconLocation = $ico; $s.Save(); $p = [Environment]::GetFolderPath('Programs'); $sm = $ws.CreateShortcut($p + '\CyberZero.lnk'); $sm.TargetPath = '%INSTALL_DIR%\cyberzero.exe'; $sm.WorkingDirectory = '%INSTALL_DIR%'; $sm.IconLocation = $ico; $sm.Save();"

echo [4/4] 正在註冊 Office 檔案類型關聯...
set "EXE_PATH=%INSTALL_DIR%\cyberzero.exe"
set "CAP_PATH=Software\CyberZero\Capabilities"
reg add "HKCU\%CAP_PATH%" /v "ApplicationName" /d "CyberZero" /f >nul
reg add "HKCU\%CAP_PATH%" /v "ApplicationDescription" /d "CyberZero 輕量 Office 文件閱讀與編輯器" /f >nul
reg add "HKCU\%CAP_PATH%" /v "ApplicationIcon" /d "\"%EXE_PATH%\",0" /f >nul
reg add "HKCU\Software\RegisteredApplications" /v "CyberZero" /d "%CAP_PATH%" /f >nul
reg add "HKCU\Software\Classes\Applications\cyberzero.exe" /v "FriendlyAppName" /d "CyberZero" /f >nul
reg add "HKCU\Software\Classes\Applications\cyberzero.exe\DefaultIcon" /ve /d "\"%EXE_PATH%\",0" /f >nul
reg add "HKCU\Software\Classes\Applications\cyberzero.exe\shell\open\command" /ve /d "\"%EXE_PATH%\" \"%%1\"" /f >nul

for %%E in (docx doc xlsx xlsm xls csv ods pptx ppt pdf) do (
    reg add "HKCU\Software\Classes\CyberZero.%%E" /ve /d "Office 文件 (.%%E)" /f >nul
    reg add "HKCU\Software\Classes\CyberZero.%%E\DefaultIcon" /ve /d "\"%EXE_PATH%\",0" /f >nul
    reg add "HKCU\Software\Classes\CyberZero.%%E\shell\open" /ve /d "使用 CyberZero 開啟" /f >nul
    reg add "HKCU\Software\Classes\CyberZero.%%E\shell\open\command" /ve /d "\"%EXE_PATH%\" \"%%1\"" /f >nul
    reg add "HKCU\Software\Classes\.%%E\OpenWithProgids" /v "CyberZero.%%E" /d "" /f >nul
    reg add "HKCU\%CAP_PATH%\FileAssociations" /v ".%%E" /d "CyberZero.%%E" /f >nul
    reg add "HKCU\Software\Classes\Applications\cyberzero.exe\SupportedTypes" /v ".%%E" /d "" /f >nul
)

echo.
echo ========================================================
echo   [OK] CyberZero v1.0.0 安裝完成！
echo   • 安裝路徑: %INSTALL_DIR%\cyberzero.exe
echo   • 桌面與開始功能表捷徑已建立
echo   • 啟動後可點擊工具列「預設程式」一鍵接管 Word / Excel / PPT 預設開啟！
echo ========================================================
echo.
start "" "%INSTALL_DIR%\cyberzero.exe"
pause
